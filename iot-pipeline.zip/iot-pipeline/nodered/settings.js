module.exports = {
    // ── Security ──────────────────────────────────────────────────────────
    // Disable editor authentication for local development
    adminAuth: undefined,

    // ── HTTP ─────────────────────────────────────────────────────────────
    uiPort: process.env.PORT || 1880,
    uiHost: "0.0.0.0",

    // ── Logging ───────────────────────────────────────────────────────────
    logging: {
        console: {
            level: "info",
            metrics: false,
            audit: false,
        },
    },

    // ── Editor ────────────────────────────────────────────────────────────
    editorTheme: {
        page: {
            title: "IoT Pipeline — Node-RED",
        },
        header: {
            title: "IoT Pipeline",
        },
        projects: {
            enabled: false,
        },
    },

    // ── Flow file ─────────────────────────────────────────────────────────
    flowFile: "flows.json",
    userDir: "/data",

    // ── Function node globals ─────────────────────────────────────────────
    functionGlobalContext: {},

    // ── Credentials secret ────────────────────────────────────────────────
    credentialSecret: "iot-pipeline-secret",
};
