"""
IoT Anomaly Detection API
=========================
FastAPI server that exposes a /predict endpoint.
Accepts sensor readings and returns anomaly classification
using Isolation Forest (ML) with Z-score as a secondary check.
"""

import logging
import time
from contextlib import asynccontextmanager

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

# ──────────────────────────────────────────────────────────────────────────────
# Logging
# ──────────────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Global model state
# ──────────────────────────────────────────────────────────────────────────────
model_state: dict = {}


def train_model() -> None:
    """
    Train an Isolation Forest on synthetic 'normal' sensor data.
    
    Normal ranges:
      - temperature  : 15 – 40 °C
      - humidity     : 30 – 80 %
      - wind_speed   : 0  – 25 m/s
    """
    logger.info("Training Isolation Forest on synthetic baseline data …")
    rng = np.random.default_rng(42)
    n = 2000

    normal_data = pd.DataFrame(
        {
            "temperature": rng.uniform(15, 40, n),
            "humidity": rng.uniform(30, 80, n),
            "wind_speed": rng.uniform(0, 25, n),
        }
    )

    scaler = StandardScaler()
    X_train = scaler.fit_transform(normal_data)

    clf = IsolationForest(
        n_estimators=200,
        contamination=0.05,   # ~5 % of training data treated as anomalies
        random_state=42,
        n_jobs=-1,
    )
    clf.fit(X_train)

    model_state["model"] = clf
    model_state["scaler"] = scaler
    logger.info("Model training complete ✓")


# ──────────────────────────────────────────────────────────────────────────────
# Lifespan (replaces deprecated @app.on_event)
# ──────────────────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    train_model()
    yield


# ──────────────────────────────────────────────────────────────────────────────
# FastAPI app
# ──────────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="IoT Anomaly Detection API",
    description="Isolation Forest-based anomaly detector for IoT sensor data",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ──────────────────────────────────────────────────────────────────────────────
# Schemas
# ──────────────────────────────────────────────────────────────────────────────
class SensorReading(BaseModel):
    temperature: float = Field(..., description="Air temperature in °C", example=22.5)
    humidity: float = Field(..., description="Relative humidity in %", example=55.0)
    wind_speed: float = Field(..., description="Wind speed in m/s", example=8.3)


class AnomalyResponse(BaseModel):
    anomaly: bool = Field(..., description="True if the reading is anomalous")
    score: float = Field(..., description="Isolation Forest anomaly score (-1 to 1; lower = more anomalous)")
    zscore_max: float = Field(..., description="Max Z-score across all features")
    reason: str = Field(..., description="Human-readable explanation")
    input: SensorReading
    latency_ms: float


# ──────────────────────────────────────────────────────────────────────────────
# Helper: Z-score anomaly check
# ──────────────────────────────────────────────────────────────────────────────
# Population statistics for 'normal' ranges
NORMAL_STATS = {
    "temperature": {"mean": 27.5, "std": 7.2},
    "humidity": {"mean": 55.0, "std": 14.4},
    "wind_speed": {"mean": 12.5, "std": 7.2},
}

Z_THRESHOLD = 3.0  # readings beyond 3-sigma are flagged


def compute_zscore(reading: SensorReading) -> tuple[float, str]:
    """Return (max_z, reason_string)."""
    zscores = {}
    for field, stats in NORMAL_STATS.items():
        val = getattr(reading, field)
        z = abs((val - stats["mean"]) / stats["std"])
        zscores[field] = z

    max_field = max(zscores, key=zscores.get)
    max_z = zscores[max_field]

    if max_z > Z_THRESHOLD:
        reason = f"{max_field} is {max_z:.1f}σ away from normal (value={getattr(reading, max_field):.2f})"
    else:
        reason = "All readings within normal range"

    return max_z, reason


# ──────────────────────────────────────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────────────────────────────────────
@app.get("/health", tags=["Meta"])
def health():
    """Liveness probe."""
    return {"status": "ok", "model_loaded": "model" in model_state}


@app.get("/", tags=["Meta"])
def root():
    return {
        "message": "IoT Anomaly Detection API",
        "docs": "/docs",
        "predict": "/predict",
    }


@app.post("/predict", response_model=AnomalyResponse, tags=["Inference"])
def predict(reading: SensorReading):
    """
    Classify a sensor reading as normal or anomalous.

    Returns:
    - **anomaly**: boolean flag
    - **score**: raw Isolation Forest decision score
    - **zscore_max**: highest Z-score across features
    - **reason**: human-readable explanation
    """
    if "model" not in model_state:
        raise HTTPException(status_code=503, detail="Model not yet loaded")

    t0 = time.perf_counter()

    # Prepare feature matrix
    X = np.array([[reading.temperature, reading.humidity, reading.wind_speed]])
    X_scaled = model_state["scaler"].transform(X)

    # Isolation Forest
    # predict: 1 = normal, -1 = anomaly
    prediction = model_state["model"].predict(X_scaled)[0]
    # decision_function: negative = more anomalous
    raw_score = float(model_state["model"].decision_function(X_scaled)[0])

    is_anomaly_if = prediction == -1

    # Z-score secondary check
    max_z, reason = compute_zscore(reading)
    is_anomaly_z = max_z > Z_THRESHOLD

    # An anomaly is flagged if EITHER method agrees (union rule)
    is_anomaly = is_anomaly_if or is_anomaly_z

    latency = (time.perf_counter() - t0) * 1000

    logger.info(
        "predict | temp=%.1f hum=%.1f wind=%.1f | anomaly=%s score=%.4f z=%.2f | %.1fms",
        reading.temperature,
        reading.humidity,
        reading.wind_speed,
        is_anomaly,
        raw_score,
        max_z,
        latency,
    )

    return AnomalyResponse(
        anomaly=is_anomaly,
        score=round(raw_score, 4),
        zscore_max=round(max_z, 3),
        reason=reason if is_anomaly else "Reading is within normal parameters",
        input=reading,
        latency_ms=round(latency, 2),
    )


@app.get("/stats", tags=["Meta"])
def stats():
    """Return normal distribution statistics used by Z-score check."""
    return {
        "normal_ranges": {
            "temperature": {"min": 15, "max": 40, "unit": "°C"},
            "humidity": {"min": 30, "max": 80, "unit": "%"},
            "wind_speed": {"min": 0, "max": 25, "unit": "m/s"},
        },
        "zscore_threshold": Z_THRESHOLD,
        "isolation_forest_contamination": 0.05,
    }
